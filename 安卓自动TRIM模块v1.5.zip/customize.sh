SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=true
LATESTARTSERVICE=true

id="`grep_prop id $TMPDIR/module.prop`"
var_device="`getprop ro.product.device`"
var_version="`grep_prop ro.build.version.release`"
B="`grep_prop author $TMPDIR/module.prop`"
C="`grep_prop name $TMPDIR/module.prop`"
D="`grep_prop description $TMPDIR/module.prop`"

ui_print "*********************************"
ui_print "     安卓自动TRIM模块CRON定时版"
ui_print "*********************************"
ui_print "- 您的设备:$var_device"
ui_print "- 系统版本:$var_version"
ui_print "- 原创作者:酷安@阳江magma"
ui_print "- 参与者:酷安@Ron_Tuo"
sleep 1
ui_print "注意:本模块默认2小时进行一次内核碎片写回与TRIM操作"
ui_print "当然,你也可以在Magisk/KernelSU管理器中自己按启动键手动执行"
sleep 1
ui_print "- 正在安装模块"    
set_perm_recursive  $MODPATH  0  0  0755  0755

ui_print "- 模块安装完成,重启生效!"
ui_print "- 祝您玩机愉快~"
